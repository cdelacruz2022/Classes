import UIKit

class allfeatures {
    var Engine = "V6/V8 or I6/I8"
    var Interior = "Leather or Vinyl"
    var ColorOfCar = " Black or White Exterior"
    var WheelColor = " Silver or Black Wheels"
    
    func insideFeature() {
        print(" \(Engine) \(Interior) \(ColorOfCar) \(WheelColor) ")
    }
}
var carFeatures = allfeatures()
carFeatures.insideFeature()

